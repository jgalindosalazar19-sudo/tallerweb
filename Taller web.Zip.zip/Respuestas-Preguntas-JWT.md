# Taller 4 — Respuestas de comprobación: Seguridad de la API con JWT

Estas respuestas siguen la implementación de la guía y el código integrado en este proyecto. Completa los espacios de capturas después de ejecutar la API en Visual Studio y Scalar.

## 1. La clave secreta

La clave se deja vacía en `appsettings.json` para que la configuración general del proyecto no contenga un secreto compartido. En desarrollo se define en `appsettings.Development.json`, que carga la configuración local del entorno de desarrollo. En producción debe suministrarse mediante la variable de entorno `Jwt__Key`, sin guardar la clave real en el repositorio.

Al borrar temporalmente `Jwt:Key` de `appsettings.Development.json`, la aplicación toma el valor vacío de `appsettings.json`. Al iniciar, la validación de `Program.cs` detecta que tiene menos de 32 caracteres y lanza el error: `Jwt:Key debe tener al menos 32 caracteres.`

Si alguien conoce la clave de firma, podría crear tokens JWT con una firma válida y claims inventados, por ejemplo, haciéndose pasar por otra persona. La API podría aceptar esos tokens mientras cumplan las demás validaciones, por lo que la clave debe mantenerse privada.

**Captura pendiente:** iniciar la API después de quitar temporalmente la clave y mostrar el error. Restaura la clave al terminar.

## 2. Qué hay dentro del token

El token generado por este proyecto contiene tres claims:

- `sub`: identificador (`idPersona`) de la persona.
- `email`: correo de la persona.
- `name`: nombre y apellido.

No contiene la contraseña. El contenido de un JWT firmado está codificado en Base64URL, pero no cifrado; por eso cualquier persona que tenga el token puede decodificar y leer su payload. La firma permite comprobar que el contenido no fue alterado, pero no lo vuelve secreto. Si se incluyera la contraseña, alguien que consiguiera el token podría leerla.

La respuesta de `GET /api/Auth/yo` muestra esos mismos datos: `idPersona`, `correo` y `nombre`.

**Captura pendiente:** decodifica el token de tu propio login en un decodificador JWT y captura el payload. No compartas el token real en público.

## 3. Autenticación no es autorización

Suponiendo que existe la persona con id `9`, con la implementación de esta unidad Ana (id `5`) podría ejecutar `DELETE /api/Personas/9` y la API respondería `204 No Content`, porque `[Authorize]` comprueba que la petición venga de una persona autenticada con un token válido, pero el método `DeletePersona` todavía no comprueba que el id solicitado pertenezca a esa persona. Si el id `9` no existe, respondería `404 Not Found`.

Para que cada persona solo pueda borrar su propio registro, el método debe leer el claim `sub`, convertirlo a entero y compararlo con el id de la ruta antes de borrar:

```csharp
var idDelToken = User.FindFirst("sub")?.Value;

if (!int.TryParse(idDelToken, out var idAutenticado))
    return Forbid();

if (id != idAutenticado)
    return Forbid();
```

Ese bloque se coloca al inicio de `DeletePersona`, antes de buscar y eliminar el registro. Cuando la persona está autenticada pero no es la dueña, debe responder `403 Forbidden`. `401 Unauthorized` corresponde a una petición que no presenta una autenticación válida.

**Nota:** esta comprobación se explica porque la pregunta la solicita; no se añadió al controlador, ya que la guía de esta unidad indica que todavía no se implementa la propiedad por usuario.

## 4. Expiración

Si el token dura 60 minutos y alguien lo obtiene 5 minutos después del login, nominalmente podría utilizarlo durante los 55 minutos restantes, hasta que expire. La configuración del proyecto tiene una tolerancia de reloj (`ClockSkew`) de un minuto para pequeñas diferencias entre relojes.

Al establecer `ExpiresMinutes` en `1`, iniciar sesión y esperar dos minutos, la petición a `GET /api/Personas` debe responder `401 Unauthorized`, porque el token ya expiró. Una duración corta limita el tiempo durante el cual alguien podría aprovechar un token robado. Después de la prueba, restaura `ExpiresMinutes` a `60`.

**Capturas pendientes:** login con token de un minuto y respuesta `401` al usarlo después de esperar dos minutos.

## 5. Correos repetidos

El login busca la primera persona cuyo correo coincida con `FirstOrDefaultAsync`. Si existen dos registros con el mismo correo y contraseñas distintas, la consulta puede seleccionar uno de ellos; la contraseña del otro registro no permitirá iniciar sesión contra el registro seleccionado. Además, el correo deja de identificar de forma única a una persona y el resultado puede ser ambiguo.

Se debe crear un índice único para `correo`. Una opción es configurarlo en `AppDBContext`:

```csharp
protected override void OnModelCreating(ModelBuilder modelBuilder)
{
    modelBuilder.Entity<Persona>()
        .HasIndex(p => p.correo)
        .IsUnique();
}
```

Antes de aplicar la migración hay que revisar y corregir los correos duplicados que ya existan; de lo contrario, SQL Server no podrá crear el índice único. Después, en la Consola del Administrador de paquetes de Visual Studio, con `WebApi2026New` como proyecto predeterminado, se ejecuta:

```powershell
Add-Migration CorreoUnico
Update-Database
```

## Lista de evidencias para el PDF final

- [ ] Scalar: `POST /api/Auth/registro` responde `200`.
- [ ] Scalar: `POST /api/Auth/login` devuelve el token.
- [ ] Scalar: `GET /api/Personas` sin token responde `401`.
- [ ] Scalar: `GET /api/Personas` con token responde `200`.
- [ ] SQL Server: tabla `Personas` muestra el hash BCrypt guardado en `password` (la guía indica que empieza por `$2a$`).
- [ ] Captura de la pregunta 1: error por clave JWT vacía.
- [ ] Captura de la pregunta 2: payload decodificado de JWT.
- [ ] Capturas de la pregunta 4: token de un minuto y respuesta `401` tras esperar.
- [ ] Enlace al repositorio con los cambios.

Las capturas no se pueden generar desde este entorno porque requieren ejecutar tu API, Scalar y SQL Server LocalDB en tu equipo. El código, las respuestas y esta lista quedan preparados para que agregues esas evidencias reales.
