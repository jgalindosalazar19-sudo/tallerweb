# WebApi2026New — Taller 4: Seguridad de la API con JWT

Se integró autenticación JWT sobre la API existente de Personas y Direcciones, siguiendo la guía `Seguridad de la API con JWT`.

## Cambios incluidos

- `POST /api/Auth/registro`: registra una persona y guarda su contraseña con BCrypt.
- `POST /api/Auth/login`: verifica las credenciales y devuelve un JWT.
- `GET /api/Auth/yo`: devuelve los claims `sub`, `email` y `name` del token.
- `PersonasController` y `DireccionesController`: ahora requieren autenticación (`[Authorize]`).
- `POST /api/Personas`: también almacena la contraseña como hash.
- `PUT /api/Personas/{id}`: recibe `PersonaUpdateDTO` y no permite sobrescribir el hash de la contraseña.
- Scalar/OpenAPI: incluye el esquema Bearer para pegar el JWT.
- `WebApi2026New.http`: contiene las solicitudes de registro, login y pruebas con y sin token.

## Ejecutar

1. Abre `WebApi2026New.slnx` o el proyecto `WebApi2026New.csproj` en Visual Studio.
2. Restaura los paquetes NuGet (o ejecuta `dotnet restore` en la carpeta del `.csproj`).
3. Comprueba que SQL Server LocalDB esté instalado e iniciado y que `DefaultConnection` en `appsettings.json` apunte a la base correcta.
4. Ejecuta el perfil `https`. Scalar se abre en `https://localhost:7186/scalar/v1`.
5. Prueba primero `POST /api/Auth/registro`, después `POST /api/Auth/login`. Copia el campo `token` y pégalo en la autenticación Bearer de Scalar, sin escribir la palabra `Bearer`.
6. Comprueba que `GET /api/Personas` sin token responde `401` y con token responde `200`.

## Base de datos y migraciones: revisar antes de ejecutar

El ZIP original no incluía una carpeta `Migrations`. Por eso no ejecuté ni generé migraciones automáticamente: no tengo acceso a tu instancia local de SQL Server y no puedo saber si `MyDB2026` contiene información que debas conservar.

En Visual Studio abre **Herramientas → Administrador de paquetes NuGet → Consola del Administrador de paquetes**, selecciona `WebApi2026New` como proyecto predeterminado y ejecuta:

```powershell
Get-Migration
```

- Si ya tienes migraciones aplicadas y coinciden con las tablas `Personas` y `Direcciones`, no hagas cambios en la base.
- Si la base está vacía y no hay migraciones, crea la inicial y aplica el esquema:

```powershell
Add-Migration Inicial
Update-Database
```

- Si `MyDB2026` ya tiene tablas o datos, **no ejecutes `Drop-Database` ni `Update-Database` a ciegas**: primero respalda la base. La guía propone reiniciar las migraciones con `Drop-Database` cuando no existe la carpeta `Migrations`, pero ese comando elimina la base y sus datos de prueba.

## Clave JWT

`appsettings.json` deja `Jwt:Key` vacío y `appsettings.Development.json` contiene una clave aleatoria de desarrollo de 64 caracteres para poder ejecutar localmente. No reutilices esa clave en producción ni publiques claves reales. En el servidor define la variable de entorno `Jwt__Key` con un secreto aleatorio de al menos 32 bytes.

## Usuarios existentes

Las personas que ya estaban guardadas con la contraseña en texto plano no podrán iniciar sesión con el verificador BCrypt. Para las pruebas de la guía, registra una persona nueva desde `/api/Auth/registro`. No se modificaron ni se borraron registros existentes.

## Alcance de la protección

La guía de esta unidad no implementa roles ni propiedad por usuario: cualquier persona autenticada puede usar los endpoints protegidos. Por tanto, `[Authorize]` verifica que exista un token válido, pero todavía no impide que una persona autenticada consulte, actualice o elimine el registro de otra. Esa comprobación de propietario queda como mejora posterior indicada por la guía.

## Validación realizada aquí

Se verificaron la estructura del proyecto, la presencia de los archivos añadidos, el JSON de configuración y el XML del `.csproj`. No pude compilar ni probar contra LocalDB porque este entorno no tiene instalado el SDK/comando `dotnet` ni acceso a tu instancia SQL Server. La compilación y las pruebas finales deben ejecutarse en tu Visual Studio.
