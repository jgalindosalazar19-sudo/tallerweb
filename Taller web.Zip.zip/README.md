# WebApi2026New — Seguridad JWT

Proyecto de Programación Web con autenticación JWT y hash BCrypt.

## Incluye
- Registro y login mediante `AuthController`.
- Generación y validación de JWT.
- Protección de Personas y Direcciones con `[Authorize]`.
- Hash BCrypt para contraseñas.
- Pruebas HTTP en `WebApi2026New.http`.
- `DOCUMENTACION_Y_EVIDENCIAS_JWT.pdf`: guía visual y espacios para evidencias auténticas.
- `Respuestas-Preguntas-JWT.md`: respuestas de comprobación.

## Antes de ejecutar
1. Configura la cadena de conexión SQL Server en `appsettings.json`.
2. Configura una clave JWT de desarrollo segura en `appsettings.Development.json` o mediante User Secrets / variables de entorno.
3. Revisa migraciones con `Get-Migration`; no elimines la base de datos sin respaldo.
4. Ejecuta `dotnet restore` y `dotnet build`.
5. Inicia la API y prueba los endpoints en Scalar.

## GitHub
Usuario: https://github.com/jgalindosalazar19-sudo

Crea un repositorio vacío llamado `WebApi2026New` y sigue los comandos de publicación incluidos en el PDF.
